package database;

public class OrderDatabase {
public void placeOrder(String customerName) {
System.out.println("Order placed for " + customerName);
}
}
